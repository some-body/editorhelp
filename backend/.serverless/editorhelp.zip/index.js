module.exports.handler = require('./dist/app').handler;
